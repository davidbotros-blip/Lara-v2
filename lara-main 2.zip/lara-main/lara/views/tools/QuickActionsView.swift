//
//  QuickActionsView.swift
//  lara
//
//  Created by ruter on 31.05.26.
//

import SwiftUI

struct QuickActionsView: View {
    @ObservedObject private var mgr = laramgr.shared
    @AppStorage("qa.confirmDangerousActions") private var confirmDangerous: Bool = true
    @AppStorage("qa.showASLRState")           private var showASLRState: Bool   = true

    @State private var aslrEnabled: Bool = aslrstate
    @State private var killTarget: String = "SpringBoard"
    @State private var statusMessage: String?

    var body: some View {
        List {
            if !mgr.dsready {
                Section {
                    Text("Kernel R/W is not ready. Run the exploit first.")
                        .foregroundColor(.secondary)
                }
            }

            // Respring & Panic
            Section(header: HeaderLabel(text: "SpringBoard", icon: "house")) {
                ActionRow(
                    title: "Respring",
                    subtitle: "Restart SpringBoard gracefully",
                    icon: "arrow.clockwise.circle",
                    color: .blue,
                    disabled: !mgr.dsready
                ) {
                    mgr.respring()
                }

                ActionRow(
                    title: "Panic!",
                    subtitle: "Write to read-only kernel memory (5 s delay)",
                    icon: "exclamationmark.octagon",
                    color: .red,
                    disabled: !mgr.dsready
                ) {
                    if confirmDangerous {
                        Alertinator.shared.alert(
                            title: "Trigger Kernel Panic?",
                            body: "This will deliberately write to read-only kernel memory after a 5-second delay, causing a device restart. Are you sure?",
                            actionLabel: "Panic!"
                        ) {
                            mgr.panic()
                        }
                    } else {
                        mgr.panic()
                    }
                }
            }

            // ASLR
            Section(
                header: HeaderLabel(text: "ASLR", icon: "shuffle"),
                footer: Text("Address Space Layout Randomization. Toggle for debugging purposes.")
            ) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("ASLR State")
                            .fontWeight(.medium)
                        if showASLRState {
                            Text(aslrEnabled ? "Enabled" : "Disabled")
                                .font(.caption)
                                .foregroundColor(aslrEnabled ? .red : .green)
                                .monospaced()
                        }
                    }
                    Spacer()
                    Button {
                        getaslrstate()
                        aslrEnabled = aslrstate
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                    .buttonStyle(.borderless)
                }

                ActionRow(
                    title: "Toggle ASLR",
                    subtitle: aslrEnabled ? "Currently enabled — tap to disable" : "Currently disabled — tap to enable",
                    icon: "shuffle.circle",
                    color: aslrEnabled ? .orange : .green,
                    disabled: !mgr.dsready
                ) {
                    toggleaslr()
                    getaslrstate()
                    aslrEnabled = aslrstate
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                    statusMessage = "ASLR is now \(aslrEnabled ? "enabled" : "disabled")."
                }
            }

            // Kill / Crash process
            Section(
                header: HeaderLabel(text: "Kill Process", icon: "xmark.circle"),
                footer: Text("Sends a crash signal to the named process. Use the exact binary name.")
            ) {
                HStack {
                    Text("Process:")
                    TextField("e.g. SpringBoard", text: $killTarget)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .foregroundColor(.secondary)
                        .monospaced()
                        .multilineTextAlignment(.trailing)
                }

                ActionRow(
                    title: "Kill \"\(killTarget.isEmpty ? "…" : killTarget)\"",
                    subtitle: "Crash the named process",
                    icon: "bolt.slash.circle",
                    color: .red,
                    disabled: !mgr.dsready || killTarget.trimmingCharacters(in: .whitespaces).isEmpty
                ) {
                    let target = killTarget.trimmingCharacters(in: .whitespaces)
                    guard !target.isEmpty else { return }
                    if confirmDangerous {
                        Alertinator.shared.alert(
                            title: "Kill \"\(target)\"?",
                            body: "This will crash the process named \"\(target)\".",
                            actionLabel: "Kill"
                        ) {
                            target.withCString { _ = crashproc($0) }
                            statusMessage = "Kill signal sent to \(target)."
                        }
                    } else {
                        target.withCString { _ = crashproc($0) }
                        statusMessage = "Kill signal sent to \(target)."
                    }
                }

                // Quick-kill presets
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(["SpringBoard", "backboardd", "mediaserverd", "MobileMail", "MobileSafari"], id: \.self) { preset in
                            Button(preset) {
                                killTarget = preset
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                            }
                            .font(.caption)
                            .buttonStyle(.bordered)
                            .buttonBorderShape(.capsule)
                        }
                    }
                    .padding(.vertical, 2)
                }
                .listRowInsets(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
            }

            // Settings
            Section(header: HeaderLabel(text: "Settings", icon: "gearshape")) {
                Toggle("Confirm dangerous actions", isOn: $confirmDangerous)
                Toggle("Show ASLR state label",    isOn: $showASLRState)
            }
        }
        .navigationTitle("Quick Actions")
        .alert("Status", isPresented: .constant(statusMessage != nil)) {
            Button("OK") { statusMessage = nil }
        } message: {
            Text(statusMessage ?? "")
        }
        .onAppear {
            if mgr.dsready {
                getaslrstate()
                aslrEnabled = aslrstate
            }
        }
    }
}

// MARK: - Reusable action row

private struct ActionRow: View {
    let title: String
    let subtitle: String
    let icon: String
    let color: Color
    let disabled: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(color.opacity(0.15))
                        .frame(width: 36, height: 36)
                    Image(systemName: icon)
                        .foregroundColor(disabled ? .gray : color)
                        .imageScale(.medium)
                }
                VStack(alignment: .leading, spacing: 1) {
                    Text(title)
                        .foregroundColor(disabled ? .secondary : .primary)
                        .fontWeight(.medium)
                    Text(subtitle)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                }
            }
        }
        .disabled(disabled)
    }
}
